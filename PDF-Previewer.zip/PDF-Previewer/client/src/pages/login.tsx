import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Building2, ArrowRight } from "lucide-react";
import generatedImage from '@assets/generated_images/abstract_tech_gradient_background_for_login_page.png';

export default function Login() {
  const [, setLocation] = useLocation();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLocation("/dashboard");
  };

  return (
    <div className="min-h-screen w-full flex">
      {/* Left Column - Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-background">
        <div className="max-w-md w-full space-y-8 animate-in slide-in-from-left-8 duration-700 fade-in">
          <div className="space-y-2">
            <div className="flex items-center gap-2 font-heading font-bold text-2xl text-primary mb-6">
              <div className="size-10 rounded-xl bg-primary text-primary-foreground flex items-center justify-center shadow-lg shadow-primary/20">
                <Building2 className="size-6" />
              </div>
              OrgManager
            </div>
            <h1 className="text-3xl font-bold tracking-tight">Welcome back</h1>
            <p className="text-muted-foreground">
              Enter your admin credentials to access the management dashboard.
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input 
                  id="email" 
                  placeholder="admin@example.com" 
                  type="email" 
                  required 
                  className="h-11"
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                  <a href="#" className="text-sm font-medium text-primary hover:underline">
                    Forgot password?
                  </a>
                </div>
                <Input 
                  id="password" 
                  type="password" 
                  required 
                  className="h-11"
                />
              </div>
            </div>

            <Button type="submit" className="w-full h-11 text-base shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all">
              Sign in to Dashboard
              <ArrowRight className="ml-2 size-4" />
            </Button>
          </form>
          
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-border" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">
                Or continue with
              </span>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <Button variant="outline" className="h-11">
              GitHub
            </Button>
            <Button variant="outline" className="h-11">
              Google
            </Button>
          </div>
        </div>
      </div>

      {/* Right Column - Visual */}
      <div className="hidden lg:flex w-1/2 relative bg-muted text-white overflow-hidden">
        <div className="absolute inset-0 bg-zinc-900/10 z-10" />
        <img 
          src={generatedImage} 
          alt="Abstract Background" 
          className="absolute inset-0 w-full h-full object-cover animate-in fade-in duration-1000 scale-105"
        />
        
        <div className="relative z-20 flex flex-col justify-between h-full p-12 bg-gradient-to-t from-black/60 via-transparent to-transparent">
          <div className="flex justify-end">
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-full px-4 py-1 text-sm font-medium">
              Frontend Assignment 2025
            </div>
          </div>
          
          <div className="max-w-md space-y-4">
            <blockquote className="text-2xl font-heading font-medium leading-relaxed">
              "This dashboard helps us manage thousands of organizations with ease. The multi-tenant architecture is seamless."
            </blockquote>
            <div className="flex items-center gap-4 pt-4">
              <div className="size-10 rounded-full bg-white/20 backdrop-blur-md" />
              <div>
                <div className="font-semibold">Alex Chen</div>
                <div className="text-sm text-white/80">Senior Systems Architect</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
