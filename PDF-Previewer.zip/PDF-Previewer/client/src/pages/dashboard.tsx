import { Layout } from "@/components/layout";
import { mockOrgs } from "@/lib/data";
import { OrgCard } from "@/components/org-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Plus, 
  Search, 
  Filter, 
  ArrowUpDown,
  LayoutGrid,
  List as ListIcon
} from "lucide-react";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";

export default function Dashboard() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState("");

  const filteredOrgs = mockOrgs.filter(org => 
    org.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    org.adminEmail.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Layout>
      <div className="space-y-8">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              Manage your organizations and their database collections.
            </p>
          </div>
          
          <Dialog>
            <DialogTrigger asChild>
              <Button size="lg" className="shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all">
                <Plus className="mr-2 size-4" />
                New Organization
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Create Organization</DialogTitle>
                <DialogDescription>
                  Create a new organization and provision its database collection.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">Organization Name</Label>
                  <Input id="name" placeholder="Acme Inc." />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="email">Admin Email</Label>
                  <Input id="email" type="email" placeholder="admin@example.com" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="password">Admin Password</Label>
                  <Input id="password" type="password" />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit">Create Organization</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats Row */}
        <div className="grid gap-4 md:grid-cols-3">
          <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
            <div className="text-sm font-medium text-muted-foreground">Total Organizations</div>
            <div className="text-2xl font-bold mt-2">{mockOrgs.length}</div>
            <div className="text-xs text-emerald-500 mt-1 font-medium">+2 from last month</div>
          </div>
          <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
            <div className="text-sm font-medium text-muted-foreground">Active Collections</div>
            <div className="text-2xl font-bold mt-2">{mockOrgs.filter(o => o.status === 'active').length}</div>
            <div className="text-xs text-muted-foreground mt-1">98.5% uptime</div>
          </div>
          <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
            <div className="text-sm font-medium text-muted-foreground">Total Users</div>
            <div className="text-2xl font-bold mt-2">
              {mockOrgs.reduce((acc, curr) => acc + curr.userCount, 0).toLocaleString()}
            </div>
            <div className="text-xs text-emerald-500 mt-1 font-medium">+12% growth</div>
          </div>
        </div>

        {/* Filters & Controls */}
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
          <div className="relative w-full sm:w-96">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input 
              placeholder="Filter organizations..." 
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <Button variant="outline" size="sm" className="h-9">
              <Filter className="mr-2 size-4" />
              Filter
            </Button>
            <Button variant="outline" size="sm" className="h-9">
              <ArrowUpDown className="mr-2 size-4" />
              Sort
            </Button>
            <div className="h-4 w-px bg-border mx-2 hidden sm:block" />
            <div className="bg-muted p-1 rounded-lg hidden sm:flex">
              <Button 
                variant="ghost" 
                size="icon" 
                className={viewMode === 'grid' ? 'bg-background shadow-sm h-7 w-7' : 'h-7 w-7 text-muted-foreground'}
                onClick={() => setViewMode('grid')}
              >
                <LayoutGrid className="size-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className={viewMode === 'list' ? 'bg-background shadow-sm h-7 w-7' : 'h-7 w-7 text-muted-foreground'}
                onClick={() => setViewMode('list')}
              >
                <ListIcon className="size-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Content Grid */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredOrgs.map((org) => (
            <OrgCard key={org.id} org={org} />
          ))}
        </div>
      </div>
    </Layout>
  );
}
