import { Organization } from "@/lib/data";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { 
  MoreVertical, 
  Users, 
  Database, 
  Calendar,
  ArrowUpRight
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format } from "date-fns";

interface OrgCardProps {
  org: Organization;
}

export function OrgCard({ org }: OrgCardProps) {
  return (
    <Card className="group relative overflow-hidden transition-all hover:shadow-lg hover:border-primary/50">
      <div className="p-6 space-y-6">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h3 className="font-heading font-semibold text-lg">{org.name}</h3>
              <Badge variant={org.status === 'active' ? 'default' : 'secondary'} className="capitalize">
                {org.status}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground flex items-center gap-1">
              <Database className="size-3" />
              {org.collectionName}
            </p>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8 -mr-2 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity">
                <MoreVertical className="size-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuItem>Edit Details</DropdownMenuItem>
              <DropdownMenuItem>Manage Users</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-destructive">Delete Organization</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="grid grid-cols-2 gap-4 pt-2">
          <div className="space-y-1">
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Users className="size-3" />
              Admin
            </span>
            <p className="text-sm font-medium truncate" title={org.adminEmail}>
              {org.adminEmail}
            </p>
          </div>
          <div className="space-y-1">
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Calendar className="size-3" />
              Created
            </span>
            <p className="text-sm font-medium">
              {format(new Date(org.createdAt), 'MMM d, yyyy')}
            </p>
          </div>
        </div>
      </div>
      
      <div className="bg-muted/30 px-6 py-3 border-t border-border flex items-center justify-between group-hover:bg-primary/5 transition-colors">
        <span className="text-xs font-medium text-muted-foreground group-hover:text-primary transition-colors">
          View Details
        </span>
        <ArrowUpRight className="size-4 text-muted-foreground group-hover:text-primary transition-colors" />
      </div>
    </Card>
  );
}
