export interface Organization {
  id: string;
  name: string;
  adminEmail: string;
  collectionName: string;
  status: 'active' | 'inactive' | 'pending';
  createdAt: string;
  userCount: number;
}

export const mockOrgs: Organization[] = [
  {
    id: "1",
    name: "Acme Corp",
    adminEmail: "admin@acme.com",
    collectionName: "org_acme_corp",
    status: "active",
    createdAt: "2024-01-15T10:00:00Z",
    userCount: 124
  },
  {
    id: "2",
    name: "Globex Inc",
    adminEmail: "ceo@globex.com",
    collectionName: "org_globex",
    status: "active",
    createdAt: "2024-02-20T14:30:00Z",
    userCount: 85
  },
  {
    id: "3",
    name: "Soylent Corp",
    adminEmail: "ops@soylent.com",
    collectionName: "org_soylent",
    status: "inactive",
    createdAt: "2024-03-05T09:15:00Z",
    userCount: 12
  },
  {
    id: "4",
    name: "Initech",
    adminEmail: "lumbergh@initech.com",
    collectionName: "org_initech",
    status: "active",
    createdAt: "2024-01-10T11:20:00Z",
    userCount: 450
  },
  {
    id: "5",
    name: "Umbrella Corp",
    adminEmail: "wesk@umbrella.com",
    collectionName: "org_umbrella",
    status: "pending",
    createdAt: "2024-04-01T16:45:00Z",
    userCount: 1
  },
  {
    id: "6",
    name: "Stark Ind",
    adminEmail: "tony@stark.com",
    collectionName: "org_stark",
    status: "active",
    createdAt: "2023-12-12T08:00:00Z",
    userCount: 1200
  }
];
